# frozen_string_literal: true

#
# Gem version
#
module Colorize
  VERSION = '1.1.0'
end
