# frozen_string_literal: true

#
# Reopen main module to define the library version
#
module Byebug
  VERSION = "11.1.3"
end
